---
name: linkedin-agent
description: >-
  Run a LinkedIn account end to end: write posts from 21 hook formulas, comment
  on other people's posts, reply to comments, score and rewrite a profile, plan
  the week, build carousels, repurpose long content, write DMs and connection
  notes, triage the inbox, audit past posts, and humanize any draft (strips em
  dashes, AI slop words and invisible characters, then scores it). Use whenever
  the user wants anything LinkedIn-related: "post about X", "comment on this",
  "reply to these comments", "optimize my profile", "plan my week", "carousel",
  "repurpose this video", "write a DM", "triage my inbox", "audit my posts", or
  "make this sound human".
---

# LinkedIn agent

One skill, eleven modes. Pick the mode that matches the request, read its
reference file, and follow it. Nothing is ever posted to LinkedIn: these modes
write, the user posts. Every mode ends with a copy-ready block and waits for an
explicit yes.

## Setup (all modes)

Read `~/.claude/linkedin/voice.md` if it exists. It is the user's voice profile
and every mode depends on it. If it is missing, copy `templates/voice.md` as the
starting point, or ask for three of the user's own past posts and infer the
voice from them. Never invent a voice.

## Modes

| the user wants to... | read |
| --- | --- |
| turn an idea into a post, get hook options | `references/post.md` |
| comment on someone else's post | `references/comment.md` |
| answer the comments under their own post | `references/reply.md` |
| score or rewrite their profile | `references/profile.md` |
| plan the week: what to post, when, who to engage | `references/plan.md` |
| humanize text, check if it sounds like AI | `references/human.md` |
| build a carousel / document post | `references/carousel.md` |
| turn a video, newsletter or transcript into posts | `references/repurpose.md` |
| write a connection note or DM sequence | `references/dm.md` |
| triage inbox messages | `references/inbox.md` |
| analyse what past posts worked | `references/audit.md` |

If the request spans modes (for example "write a post"), run the primary mode,
then run the humanize mode on the draft before showing it.

## Bundled files

- `data/hooks.json`: 21 hook formulas (used by post, plan, repurpose, audit)
- `data/rubric.json`: 100-point profile rubric (used by profile)
- `scripts/humanize.py`, `scripts/detect.py`, `scripts/slop.json`: the
  humanizer tools. Run from this skill's folder, e.g.
  `python3 scripts/humanize.py draft.txt --report` and
  `python3 scripts/detect.py draft.txt`
- `templates/voice.md`: voice profile template

## Rules that apply everywhere

- Never fabricate metrics, clients or outcomes. If a number is missing, leave
  `{{your number}}` and flag it.
- Never post, send or automate LinkedIn on the user's behalf.
